# ══════════════════════════════════════════════════════════════
# Edge App — ProGuard / R8 Rules
# ══════════════════════════════════════════════════════════════

# ── Kotlin Serialization ─────────────────────────────────────
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt

-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.agon.app.data.**$$serializer { *; }
-keepclassmembers class com.agon.app.data.** {
    *** Companion;
}
-keepclasseswithmembers class com.agon.app.data.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# ── Keep all @Serializable data classes ──────────────────────
-keep class com.agon.app.data.Rule { *; }
-keep class com.agon.app.data.DailyLog { *; }
-keep class com.agon.app.data.Achievement { *; }
-keep class com.agon.app.data.AppData { *; }
-keep class com.agon.app.data.RuleType { *; }
-keep class com.agon.app.data.RuleCategory { *; }

# ── Compose ──────────────────────────────────────────────────
-dontwarn androidx.compose.**

# ── DataStore ────────────────────────────────────────────────
-keep class androidx.datastore.** { *; }
-dontwarn androidx.datastore.**

# ── Coil ─────────────────────────────────────────────────────
-dontwarn coil3.**

# ── OkHttp / Okio ───────────────────────────────────────────
-dontwarn okhttp3.**
-dontwarn okio.**

# ── Kotlin Coroutines ────────────────────────────────────────
-dontwarn kotlinx.coroutines.**

# ── General Android ──────────────────────────────────────────
-keepattributes Signature
-keepattributes Exceptions
-keepattributes SourceFile,LineNumberTable
-keep class * extends android.app.Activity
-keep class * extends androidx.lifecycle.ViewModel

# ── Prevent stripping of enum values ─────────────────────────
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
