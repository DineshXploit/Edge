package com.agon.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.data.ALL_ACHIEVEMENTS
import com.agon.app.ui.components.AchievementCard
import com.agon.app.ui.theme.EdgeAmber
import com.agon.app.ui.theme.EdgeGreen
import com.agon.app.viewmodel.EdgeViewModel
import kotlinx.coroutines.delay

@Composable
fun AchievementsScreen(viewModel: EdgeViewModel) {
    val achievements by viewModel.achievements.collectAsState()
    val streak by viewModel.streak.collectAsState()
    val logs by viewModel.logs.collectAsState()

    val displayList = ALL_ACHIEVEMENTS.map { template ->
        achievements.find { it.id == template.id } ?: template
    }
    val unlockedCount = displayList.count { it.isUnlocked }

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(100)
        visible = true
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn() + slideInVertically { -40 }
            ) {
                Column {
                    Text(
                        text = "Achievements",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$unlockedCount of ${displayList.size} unlocked",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Progress card
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn() + slideInVertically { 40 }
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = EdgeAmber.copy(alpha = 0.1f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = EdgeAmber,
                            modifier = Modifier.size(40.dp)
                        )
                        Column {
                            Text(
                                text = "$unlockedCount / ${displayList.size}",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = EdgeAmber
                            )
                            Text(
                                text = "Current streak: $streak days \u2022 ${logs.size} total logs",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Unlocked
        val unlocked = displayList.filter { it.isUnlocked }
        if (unlocked.isNotEmpty()) {
            item {
                Text(
                    text = "UNLOCKED",
                    style = MaterialTheme.typography.labelMedium,
                    color = EdgeGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 4.dp, top = 8.dp)
                )
            }
            itemsIndexed(unlocked, key = { _, a -> a.id }) { _, achievement ->
                AchievementCard(achievement = achievement)
            }
        }

        // Locked
        val locked = displayList.filter { !it.isUnlocked }
        if (locked.isNotEmpty()) {
            item {
                Text(
                    text = "LOCKED",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 4.dp, top = 8.dp)
                )
            }
            itemsIndexed(locked, key = { _, a -> a.id }) { _, achievement ->
                AchievementCard(achievement = achievement)
            }
        }

        item { Spacer(modifier = Modifier.height(8.dp)) }
    }
}
