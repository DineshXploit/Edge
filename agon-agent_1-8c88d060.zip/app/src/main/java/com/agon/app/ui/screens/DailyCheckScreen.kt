package com.agon.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.agon.app.data.Rule
import com.agon.app.data.RuleType
import com.agon.app.data.ScoringEngine
import com.agon.app.ui.components.ScoreCircle
import com.agon.app.ui.components.scoreColor
import com.agon.app.ui.theme.EdgeGreen
import com.agon.app.ui.theme.EdgeGreenLight
import com.agon.app.ui.theme.EdgeRed
import com.agon.app.ui.theme.EdgeRedLight
import com.agon.app.viewmodel.EdgeViewModel
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun DailyCheckScreen(
    viewModel: EdgeViewModel,
    onSubmitted: () -> Unit
) {
    val rules by viewModel.rules.collectAsState()
    val responses by viewModel.currentResponses.collectAsState()
    val currentScore by viewModel.currentScore.collectAsState()
    val activeRules = rules.filter { it.isActive }
    var submitted by remember { mutableStateOf(false) }

    // Check if all rules are answered
    val allAnswered = activeRules.all { responses.containsKey(it.id) }
    val allCorrect = allAnswered && activeRules.all { rule ->
        val v = responses[rule.id]
        v != null && !ScoringEngine.isViolated(rule, v)
    }
    val anyFailed = activeRules.any { rule ->
        val v = responses[rule.id]
        v != null && ScoringEngine.isViolated(rule, v)
    }

    LaunchedEffect(Unit) {
        viewModel.initDailyCheck()
    }

    // Animate submit button bounce
    val submitScale by animateFloatAsState(
        targetValue = if (submitted) 0.95f else 1f,
        animationSpec = spring(dampingRatio = 0.4f),
        label = "submit_scale"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Daily Check-In",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Answer honestly for each rule",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Live Score
        item {
            val borderColor by animateColorAsState(
                targetValue = when {
                    allCorrect -> EdgeGreen.copy(alpha = 0.5f)
                    anyFailed -> EdgeRed.copy(alpha = 0.3f)
                    else -> Color.Transparent
                },
                animationSpec = tween(500),
                label = "score_border"
            )
            val glowElevation by animateDpAsState(
                targetValue = when {
                    allCorrect -> 8.dp
                    anyFailed -> 4.dp
                    else -> 0.dp
                },
                label = "score_glow"
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = glowElevation,
                        shape = RoundedCornerShape(24.dp),
                        ambientColor = borderColor,
                        spotColor = borderColor
                    ),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                ),
                border = if (borderColor != Color.Transparent) BorderStroke(2.dp, borderColor) else null,
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Live Score",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    ScoreCircle(score = currentScore, size = 110.dp, strokeWidth = 10.dp)
                    if (allCorrect) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "\u2728 Perfect compliance!",
                            style = MaterialTheme.typography.bodySmall,
                            color = EdgeGreen
                        )
                    }
                }
            }
        }

        if (activeRules.isEmpty()) {
            item {
                Text(
                    text = "No active rules. Go to Rules tab to create some!",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp)
                )
            }
        }

        itemsIndexed(activeRules, key = { _, rule -> rule.id }) { index, rule ->
            val value = responses[rule.id]
            val isViolated = value != null && ScoringEngine.isViolated(rule, value)
            val isCompliant = value != null && !ScoringEngine.isViolated(rule, value)

            RuleCheckCard(
                rule = rule,
                value = value,
                isViolated = isViolated,
                isCompliant = isCompliant,
                onValueChange = { viewModel.updateResponse(rule.id, it) }
            )
        }

        // Submit
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    viewModel.submitDailyLog()
                    submitted = true
                    onSubmitted()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .scale(submitScale),
                shape = RoundedCornerShape(16.dp),
                enabled = activeRules.isNotEmpty() && !submitted,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (submitted) "\u2705 Saved!" else "Save Today's Log",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun RuleCheckCard(
    rule: Rule,
    value: Float?,
    isViolated: Boolean,
    isCompliant: Boolean,
    onValueChange: (Float) -> Unit
) {
    val borderColor by animateColorAsState(
        targetValue = when {
            isCompliant -> EdgeGreen.copy(alpha = 0.5f)
            isViolated -> EdgeRed.copy(alpha = 0.5f)
            else -> Color.Transparent
        },
        animationSpec = tween(400),
        label = "rule_border_${rule.id}"
    )
    val bgColor by animateColorAsState(
        targetValue = when {
            isCompliant -> EdgeGreen.copy(alpha = 0.04f)
            isViolated -> EdgeRed.copy(alpha = 0.04f)
            else -> MaterialTheme.colorScheme.surfaceContainerHigh
        },
        animationSpec = tween(400),
        label = "rule_bg_${rule.id}"
    )
    val cardScale by animateFloatAsState(
        targetValue = if (value != null) 1f else 0.98f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "card_scale_${rule.id}"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(cardScale),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = if (borderColor != Color.Transparent) BorderStroke(1.5.dp, borderColor) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = rule.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Penalty: -${rule.penalty} pts",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
                    )
                }
                Text(
                    text = rule.category.name.lowercase().replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (rule.type) {
                RuleType.BOOLEAN -> BooleanInput(value = value, onValueChange = onValueChange)
                RuleType.SCALE_5 -> ScaleInput(value = value, maxValue = 5, onValueChange = onValueChange)
                RuleType.SCALE_10 -> ScaleInput(value = value, maxValue = 10, onValueChange = onValueChange)
            }
        }
    }
}

@Composable
fun BooleanInput(
    value: Float?,
    onValueChange: (Float) -> Unit
) {
    val yesSelected = value != null && value >= 0.5f
    val noSelected = value != null && value < 0.5f

    val yesScale by animateFloatAsState(
        targetValue = if (yesSelected) 1.03f else 1f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = 600f),
        label = "yes_bounce"
    )
    val noScale by animateFloatAsState(
        targetValue = if (noSelected) 1.03f else 1f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = 600f),
        label = "no_bounce"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
    ) {
        FilledIconButton(
            onClick = { onValueChange(1f) },
            modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .scale(yesScale),
            shape = RoundedCornerShape(14.dp),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = if (yesSelected) EdgeGreen.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (yesSelected) EdgeGreen
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Yes", fontWeight = if (yesSelected) FontWeight.Bold else FontWeight.Normal)
            }
        }

        FilledIconButton(
            onClick = { onValueChange(0f) },
            modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .scale(noScale),
            shape = RoundedCornerShape(14.dp),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = if (noSelected) EdgeRed.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (noSelected) EdgeRed
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("No", fontWeight = if (noSelected) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

@Composable
fun ScaleInput(
    value: Float?,
    maxValue: Int,
    onValueChange: (Float) -> Unit
) {
    val currentValue = value ?: (maxValue / 2f)
    val color = scoreColor((currentValue / maxValue * 100).toInt())

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "1",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "${currentValue.roundToInt()}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = "$maxValue",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Slider(
            value = currentValue,
            onValueChange = { onValueChange(it) },
            valueRange = 1f..maxValue.toFloat(),
            steps = maxValue - 2,
            colors = SliderDefaults.colors(
                thumbColor = color,
                activeTrackColor = color,
                activeTickColor = color.copy(alpha = 0.5f)
            )
        )
    }
}
