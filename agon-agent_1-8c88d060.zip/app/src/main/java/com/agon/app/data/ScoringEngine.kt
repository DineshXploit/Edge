package com.agon.app.data

object ScoringEngine {

    fun calculateScore(rules: List<Rule>, responses: Map<String, Float>): Int {
        var score = 100
        for (rule in rules) {
            if (!rule.isActive) continue
            val value = responses[rule.id] ?: continue
            val violated = isViolated(rule, value)
            if (violated) {
                score -= rule.penalty
            }
        }
        return score.coerceAtLeast(0)
    }

    fun isViolated(rule: Rule, value: Float): Boolean {
        return when (rule.type) {
            RuleType.BOOLEAN -> value < 0.5f
            RuleType.SCALE_5 -> value < 3f
            RuleType.SCALE_10 -> value < 6f
        }
    }

    fun calculateStreak(logs: List<DailyLog>): Int {
        val sorted = logs.sortedByDescending { it.date }
        var streak = 0
        for (log in sorted) {
            if (log.score >= 80) {
                streak++
            } else {
                break
            }
        }
        return streak
    }

    fun generateAnalytics(rules: List<Rule>, logs: List<DailyLog>): AnalyticsData {
        if (logs.isEmpty() || rules.isEmpty()) {
            return AnalyticsData(
                insights = listOf("Start logging your discipline to see analytics!")
            )
        }

        val violationCounts = mutableMapOf<String, Int>()
        for (log in logs) {
            for (rule in rules) {
                if (!rule.isActive) continue
                val value = log.responses[rule.id] ?: continue
                if (isViolated(rule, value)) {
                    violationCounts[rule.id] = (violationCounts[rule.id] ?: 0) + 1
                }
            }
        }

        val mostViolatedId = violationCounts.maxByOrNull { it.value }?.key
        val mostViolatedRule = rules.find { it.id == mostViolatedId }
        val mostViolatedCount = violationCounts[mostViolatedId] ?: 0

        val categoryPenalties = mutableMapOf<RuleCategory, MutableList<Float>>()
        for (rule in rules.filter { it.isActive }) {
            val violations = violationCounts[rule.id] ?: 0
            val total = logs.count { it.responses.containsKey(rule.id) }.coerceAtLeast(1)
            val complianceRate = 1f - (violations.toFloat() / total)
            categoryPenalties.getOrPut(rule.category) { mutableListOf() }.add(complianceRate)
        }
        val categoryScores = categoryPenalties.mapValues { (_, scores) ->
            if (scores.isEmpty()) 100f else scores.average().toFloat() * 100f
        }

        val weakestCategory = categoryScores.minByOrNull { it.value }?.key
        val weakestScore = categoryScores[weakestCategory] ?: 0f

        val bestLog = logs.maxByOrNull { it.score }
        val bestDay = bestLog?.date ?: ""
        val bestDayScore = bestLog?.score ?: 0

        val insights = mutableListOf<String>()
        if (mostViolatedRule != null && mostViolatedCount > 1) {
            insights.add("\"${mostViolatedRule.name}\" is your most violated rule ($mostViolatedCount times)")
        }
        if (weakestCategory != null && weakestScore < 70f) {
            val catName = weakestCategory.name.lowercase().replaceFirstChar { it.uppercase() }
            insights.add("$catName is your weakest area (${weakestScore.toInt()}% compliance)")
        }
        val recentLogs = logs.sortedByDescending { it.date }.take(7)
        val avgRecent = if (recentLogs.isNotEmpty()) recentLogs.map { it.score }.average() else 0.0
        if (avgRecent >= 85) {
            insights.add("Great week! Your average score is ${avgRecent.toInt()}. Keep it up!")
        } else if (avgRecent < 60 && recentLogs.size >= 3) {
            insights.add("Your recent scores are low (avg ${avgRecent.toInt()}). Review your rules.")
        }
        if (logs.size >= 7) {
            val streak = calculateStreak(logs)
            if (streak >= 5) {
                insights.add("Amazing $streak-day discipline streak! You're building a habit.")
            }
        }
        if (insights.isEmpty()) {
            insights.add("Keep logging daily to unlock deeper insights!")
        }

        return AnalyticsData(
            mostViolatedRule = mostViolatedRule,
            mostViolatedCount = mostViolatedCount,
            weakestCategory = weakestCategory,
            weakestCategoryScore = weakestScore,
            bestDay = bestDay,
            bestDayScore = bestDayScore,
            insights = insights,
            categoryScores = categoryScores,
            ruleViolationCounts = violationCounts
        )
    }

    fun checkAchievements(
        currentAchievements: List<Achievement>,
        streak: Int,
        totalLogs: Int,
        perfectDays: Int,
        totalRules: Int
    ): List<Achievement> {
        val now = System.currentTimeMillis()
        val updated = ALL_ACHIEVEMENTS.map { template ->
            val existing = currentAchievements.find { it.id == template.id }
            if (existing != null && existing.isUnlocked) return@map existing

            val met = when {
                template.id.startsWith("streak_") -> streak >= template.requirement
                template.id.startsWith("logs_") -> totalLogs >= template.requirement
                template.id.startsWith("perfect_") -> perfectDays >= template.requirement
                template.id.startsWith("rules_") -> totalRules >= template.requirement
                else -> false
            }
            if (met) template.copy(unlockedAt = now) else template
        }
        return updated
    }
}
