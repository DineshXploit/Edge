package com.agon.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.agon.app.ui.theme.EdgeAmber
import com.agon.app.ui.theme.EdgeAmberDark
import com.agon.app.ui.theme.EdgeRed
import kotlinx.coroutines.delay

@Composable
fun AnimatedFireIcon(
    streak: Int,
    size: Dp = 32.dp,
    modifier: Modifier = Modifier
) {
    val fireColor = when {
        streak >= 30 -> EdgeRed
        streak >= 7 -> EdgeAmberDark
        streak > 0 -> EdgeAmber
        else -> Color.Gray
    }

    // Pop animation on streak change
    var prevStreak by remember { mutableStateOf(streak) }
    var pop by remember { mutableStateOf(false) }
    LaunchedEffect(streak) {
        if (streak > prevStreak) {
            pop = true
            delay(400)
            pop = false
        }
        prevStreak = streak
    }

    val popScale by animateFloatAsState(
        targetValue = if (pop) 1.4f else 1f,
        animationSpec = spring(dampingRatio = 0.3f, stiffness = 800f),
        label = "fire_pop"
    )

    // Continuous flicker for active streaks
    val infiniteTransition = rememberInfiniteTransition(label = "fire_flicker")
    val flickerScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flicker"
    )
    val flickerRotation by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rotation"
    )

    val scale = if (streak > 0) popScale * flickerScale else popScale

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // Glow behind
        if (streak > 0) {
            Icon(
                Icons.Filled.LocalFireDepartment,
                contentDescription = null,
                tint = fireColor.copy(alpha = 0.2f),
                modifier = Modifier
                    .size(size * 1.5f)
                    .scale(flickerScale)
            )
        }
        Icon(
            Icons.Filled.LocalFireDepartment,
            contentDescription = "Streak",
            tint = fireColor,
            modifier = Modifier
                .size(size)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    rotationZ = if (streak > 0) flickerRotation else 0f
                }
        )
    }
}
