package com.agon.app.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.data.Achievement
import com.agon.app.data.ALL_ACHIEVEMENTS
import com.agon.app.data.AnalyticsData
import com.agon.app.data.AnalyticsPeriod
import com.agon.app.data.DailyLog
import com.agon.app.data.EdgeRepository
import com.agon.app.data.Rule
import com.agon.app.data.RuleCategory
import com.agon.app.data.RuleType
import com.agon.app.data.ScoringEngine
import com.agon.app.data.ThemeMode
import com.agon.app.data.UserSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class EdgeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = EdgeRepository(application)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // Onboarding
    val onboardingCompleted: StateFlow<Boolean> = repository.onboardingCompletedFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _onboardingLoaded = MutableStateFlow(false)
    val onboardingLoaded: StateFlow<Boolean> = _onboardingLoaded.asStateFlow()

    init {
        viewModelScope.launch {
            repository.onboardingCompletedFlow.collect {
                _onboardingLoaded.value = true
            }
        }
    }

    fun completeOnboarding(userName: String) {
        viewModelScope.launch {
            repository.completeOnboarding(userName)
        }
    }

    val rules: StateFlow<List<Rule>> = repository.rulesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logs: StateFlow<List<DailyLog>> = repository.logsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<UserSettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    val achievements: StateFlow<List<Achievement>> = repository.achievementsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentResponses = MutableStateFlow<Map<String, Float>>(emptyMap())
    val currentResponses: StateFlow<Map<String, Float>> = _currentResponses.asStateFlow()

    private val _currentScore = MutableStateFlow(100)
    val currentScore: StateFlow<Int> = _currentScore.asStateFlow()

    private val _newAchievement = MutableStateFlow<Achievement?>(null)
    val newAchievement: StateFlow<Achievement?> = _newAchievement.asStateFlow()

    private val _analyticsPeriod = MutableStateFlow(AnalyticsPeriod.WEEKLY)
    val analyticsPeriod: StateFlow<AnalyticsPeriod> = _analyticsPeriod.asStateFlow()

    val today: String get() = dateFormat.format(Date())

    val todayLogged: StateFlow<Boolean> = logs.combine(MutableStateFlow(today)) { logList, date ->
        logList.any { it.date == date }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val todayScore: StateFlow<Int> = logs.combine(MutableStateFlow(today)) { logList, date ->
        logList.find { it.date == date }?.score ?: -1
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), -1)

    val weeklyAvg: StateFlow<Int> = logs.combine(MutableStateFlow(Unit)) { logList, _ ->
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -7)
        val weekAgo = dateFormat.format(cal.time)
        val recentLogs = logList.filter { it.date >= weekAgo }
        if (recentLogs.isEmpty()) -1 else recentLogs.map { it.score }.average().toInt()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), -1)

    val streak: StateFlow<Int> = logs.combine(MutableStateFlow(Unit)) { logList, _ ->
        ScoringEngine.calculateStreak(logList)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val last7DaysScores: StateFlow<List<Pair<String, Int>>> = logs.combine(MutableStateFlow(Unit)) { logList, _ ->
        val result = mutableListOf<Pair<String, Int>>()
        for (i in 6 downTo 0) {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, -i)
            val dateStr = dateFormat.format(c.time)
            val score = logList.find { it.date == dateStr }?.score ?: -1
            val dayLabel = SimpleDateFormat("EEE", Locale.US).format(c.time)
            result.add(dayLabel to score)
        }
        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val last30DaysScores: StateFlow<List<Pair<String, Int>>> = logs.combine(MutableStateFlow(Unit)) { logList, _ ->
        val result = mutableListOf<Pair<String, Int>>()
        for (i in 29 downTo 0) {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, -i)
            val dateStr = dateFormat.format(c.time)
            val score = logList.find { it.date == dateStr }?.score ?: -1
            val dayLabel = SimpleDateFormat("d", Locale.US).format(c.time)
            result.add(dayLabel to score)
        }
        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Heatmap: last 90 days
    val heatmapData: StateFlow<Map<String, Int>> = logs.combine(MutableStateFlow(Unit)) { logList, _ ->
        val map = mutableMapOf<String, Int>()
        logList.forEach { log -> map[log.date] = log.score }
        map
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val analytics: StateFlow<AnalyticsData> = rules.combine(logs) { ruleList, logList ->
        ScoringEngine.generateAnalytics(ruleList, logList)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AnalyticsData())

    // Per-rule performance for bar chart
    val rulePerformance: StateFlow<List<Triple<String, Float, RuleCategory>>> =
        rules.combine(logs) { ruleList, logList ->
            if (logList.isEmpty() || ruleList.isEmpty()) return@combine emptyList()
            ruleList.filter { it.isActive }.map { rule ->
                val totalResponses = logList.count { it.responses.containsKey(rule.id) }
                val violations = logList.count { log ->
                    val v = log.responses[rule.id]
                    v != null && ScoringEngine.isViolated(rule, v)
                }
                val compliance = if (totalResponses > 0) {
                    ((totalResponses - violations).toFloat() / totalResponses) * 100f
                } else 100f
                Triple(rule.name, compliance, rule.category)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Trade lock warning
    val showTradeLockWarning: StateFlow<Boolean> = combine(settings, todayScore) { s, score ->
        s.tradeLockEnabled && score in 0 until s.tradeLockThreshold
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // Focus mode active check
    val isFocusModeActive: StateFlow<Boolean> = settings.combine(MutableStateFlow(Unit)) { s, _ ->
        if (!s.focusModeEnabled) return@combine false
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        currentHour in s.focusModeStartHour until s.focusModeEndHour
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun setAnalyticsPeriod(period: AnalyticsPeriod) {
        _analyticsPeriod.value = period
    }

    fun dismissNewAchievement() {
        _newAchievement.value = null
    }

    // ===== RULE OPERATIONS =====
    fun addRule(name: String, type: RuleType, penalty: Int, category: RuleCategory) {
        viewModelScope.launch {
            repository.addRule(Rule(name = name, type = type, penalty = penalty, category = category))
            refreshAchievements()
        }
    }

    fun updateRule(rule: Rule) {
        viewModelScope.launch { repository.updateRule(rule) }
    }

    fun deleteRule(ruleId: String) {
        viewModelScope.launch { repository.deleteRule(ruleId) }
    }

    fun toggleRule(rule: Rule) {
        viewModelScope.launch { repository.updateRule(rule.copy(isActive = !rule.isActive)) }
    }

    // ===== DAILY CHECK =====
    fun initDailyCheck() {
        val existingLog = logs.value.find { it.date == today }
        if (existingLog != null) {
            _currentResponses.value = existingLog.responses
            _currentScore.value = existingLog.score
        } else {
            _currentResponses.value = emptyMap()
            _currentScore.value = 100
        }
    }

    fun updateResponse(ruleId: String, value: Float) {
        val updated = _currentResponses.value.toMutableMap()
        updated[ruleId] = value
        _currentResponses.value = updated
        _currentScore.value = ScoringEngine.calculateScore(rules.value, updated)
    }

    fun submitDailyLog() {
        viewModelScope.launch {
            val score = ScoringEngine.calculateScore(rules.value, _currentResponses.value)
            val log = DailyLog(
                id = UUID.randomUUID().toString(),
                date = today,
                responses = _currentResponses.value,
                score = score
            )
            repository.saveDailyLog(log)
            refreshAchievements()
        }
    }

    // ===== ACHIEVEMENTS =====
    private suspend fun refreshAchievements() {
        val currentLogs = logs.value
        val currentRules = rules.value
        val currentAchievements = achievements.value
        val currentStreak = ScoringEngine.calculateStreak(currentLogs)
        val perfectDays = currentLogs.count { it.score >= 100 }
        val updated = ScoringEngine.checkAchievements(
            currentAchievements, currentStreak, currentLogs.size, perfectDays, currentRules.size
        )
        val newlyUnlocked = updated.find { a ->
            a.isUnlocked && currentAchievements.find { it.id == a.id }?.isUnlocked != true
        }
        if (newlyUnlocked != null) {
            _newAchievement.value = newlyUnlocked
        }
        repository.saveAchievements(updated)
    }

    // ===== SETTINGS =====
    fun setTheme(mode: ThemeMode) {
        viewModelScope.launch { repository.saveTheme(mode) }
    }

    fun setUserName(name: String) {
        viewModelScope.launch { repository.saveUserName(name) }
    }

    fun setNotificationTime(hour: Int, minute: Int) {
        viewModelScope.launch { repository.saveNotificationTime(hour, minute) }
    }

    fun setTradeLock(enabled: Boolean, threshold: Int) {
        viewModelScope.launch { repository.saveTradeLock(enabled, threshold) }
    }

    fun setFocusMode(enabled: Boolean, startHour: Int, endHour: Int) {
        viewModelScope.launch { repository.saveFocusMode(enabled, startHour, endHour) }
    }

    // ===== EXPORT =====
    fun generateReport(): String {
        val logsList = logs.value.sortedByDescending { it.date }
        val rulesList = rules.value
        val analyticsData = analytics.value
        val currentStreak = streak.value
        val sb = StringBuilder()
        sb.appendLine("═══════════════════════════════════════")
        sb.appendLine("   EDGE - DISCIPLINE REPORT")
        sb.appendLine("   Master the Discipline")
        sb.appendLine("═══════════════════════════════════════")
        sb.appendLine()
        sb.appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())}")
        sb.appendLine("Trader: ${settings.value.userName}")
        sb.appendLine()
        sb.appendLine("── OVERVIEW ──────────────────────────")
        sb.appendLine("Total Logged Days: ${logsList.size}")
        sb.appendLine("Current Streak: $currentStreak days")
        val avg = if (logsList.isNotEmpty()) logsList.map { it.score }.average().toInt() else 0
        sb.appendLine("Overall Average: $avg")
        sb.appendLine("Best Score: ${analyticsData.bestDayScore} (${analyticsData.bestDay})")
        sb.appendLine()
        sb.appendLine("── RULES (${rulesList.size}) ────────────────────")
        rulesList.forEach { r ->
            val status = if (r.isActive) "Active" else "Disabled"
            val typeStr = when (r.type) {
                RuleType.BOOLEAN -> "Yes/No"
                RuleType.SCALE_5 -> "Scale 1-5"
                RuleType.SCALE_10 -> "Scale 1-10"
            }
            sb.appendLine("  • ${r.name} [$typeStr] -${r.penalty}pts (${r.category.name}) [$status]")
        }
        sb.appendLine()
        sb.appendLine("── CATEGORY SCORES ───────────────────")
        analyticsData.categoryScores.forEach { (cat, score) ->
            val bar = "█".repeat((score / 10).toInt()) + "░".repeat(10 - (score / 10).toInt())
            sb.appendLine("  ${cat.name.padEnd(12)} $bar ${score.toInt()}%")
        }
        sb.appendLine()
        sb.appendLine("── INSIGHTS ──────────────────────────")
        analyticsData.insights.forEach { sb.appendLine("  → $it") }
        sb.appendLine()
        sb.appendLine("── RECENT LOGS ───────────────────────")
        logsList.take(14).forEach { log ->
            val emoji = when {
                log.score >= 90 -> "🔥"
                log.score >= 80 -> "✅"
                log.score >= 60 -> "⚠️"
                else -> "❌"
            }
            sb.appendLine("  ${log.date}  Score: ${log.score}  $emoji")
        }
        sb.appendLine()
        sb.appendLine("═══════════════════════════════════════")
        sb.appendLine("  Generated by Edge App")
        sb.appendLine("═══════════════════════════════════════")
        return sb.toString()
    }

    fun shareReport(context: Context) {
        val report = generateReport()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Edge Discipline Report")
            putExtra(Intent.EXTRA_TEXT, report)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "Share Report").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun seedDefaultRulesIfEmpty() {
        viewModelScope.launch {
            if (rules.value.isEmpty()) {
                val defaults = listOf(
                    Rule(id = UUID.randomUUID().toString(), name = "Followed Trading Setup", type = RuleType.BOOLEAN, penalty = 20, category = RuleCategory.ENTRY),
                    Rule(id = UUID.randomUUID().toString(), name = "No Revenge Trade", type = RuleType.BOOLEAN, penalty = 25, category = RuleCategory.PSYCHOLOGY),
                    Rule(id = UUID.randomUUID().toString(), name = "Respected Stop Loss", type = RuleType.BOOLEAN, penalty = 20, category = RuleCategory.RISK),
                    Rule(id = UUID.randomUUID().toString(), name = "Emotional Control", type = RuleType.SCALE_5, penalty = 15, category = RuleCategory.PSYCHOLOGY),
                    Rule(id = UUID.randomUUID().toString(), name = "Proper Exit Execution", type = RuleType.BOOLEAN, penalty = 15, category = RuleCategory.EXIT),
                )
                repository.saveRules(defaults)
            }
        }
    }
}
