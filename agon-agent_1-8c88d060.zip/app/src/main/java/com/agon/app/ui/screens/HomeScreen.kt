package com.agon.app.ui.screens

import androidx.compose.runtime.Composable

@Composable
fun HomeScreen() {
    // Placeholder - actual app uses DashboardScreen
}
