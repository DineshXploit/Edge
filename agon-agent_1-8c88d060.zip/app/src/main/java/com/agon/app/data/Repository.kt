package com.agon.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import kotlinx.serialization.encodeToString
import java.util.UUID

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "edge_data")

class EdgeRepository(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true; prettyPrint = false }

    companion object {
        private val RULES_KEY = stringPreferencesKey("rules")
        private val LOGS_KEY = stringPreferencesKey("logs")
        private val THEME_KEY = stringPreferencesKey("theme")
        private val USER_NAME_KEY = stringPreferencesKey("user_name")
        private val NOTIFICATION_KEY = stringPreferencesKey("notification_time")
        private val ACHIEVEMENTS_KEY = stringPreferencesKey("achievements")
        private val TRADE_LOCK_ENABLED = booleanPreferencesKey("trade_lock_enabled")
        private val TRADE_LOCK_THRESHOLD = intPreferencesKey("trade_lock_threshold")
        private val FOCUS_MODE_ENABLED = booleanPreferencesKey("focus_mode_enabled")
        private val FOCUS_START_HOUR = intPreferencesKey("focus_start_hour")
        private val FOCUS_END_HOUR = intPreferencesKey("focus_end_hour")
        private val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
    }

    val onboardingCompletedFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[ONBOARDING_COMPLETED] ?: false
    }

    suspend fun completeOnboarding(userName: String) {
        context.dataStore.edit { prefs ->
            prefs[ONBOARDING_COMPLETED] = true
            prefs[USER_NAME_KEY] = userName
        }
    }

    val rulesFlow: Flow<List<Rule>> = context.dataStore.data.map { prefs ->
        val raw = prefs[RULES_KEY] ?: "[]"
        try { json.decodeFromString<List<Rule>>(raw) } catch (e: Exception) { emptyList() }
    }

    suspend fun saveRules(rules: List<Rule>) {
        context.dataStore.edit { prefs ->
            prefs[RULES_KEY] = json.encodeToString(rules)
        }
    }

    suspend fun addRule(rule: Rule): Rule {
        val newRule = rule.copy(id = UUID.randomUUID().toString())
        val current = getCurrentRules()
        saveRules(current + newRule)
        return newRule
    }

    suspend fun updateRule(rule: Rule) {
        val current = getCurrentRules().toMutableList()
        val idx = current.indexOfFirst { it.id == rule.id }
        if (idx >= 0) {
            current[idx] = rule
            saveRules(current)
        }
    }

    suspend fun deleteRule(ruleId: String) {
        val current = getCurrentRules().filter { it.id != ruleId }
        saveRules(current)
    }

    private suspend fun getCurrentRules(): List<Rule> {
        var result: List<Rule> = emptyList()
        context.dataStore.edit { prefs ->
            val raw = prefs[RULES_KEY] ?: "[]"
            result = try { json.decodeFromString(raw) } catch (e: Exception) { emptyList() }
        }
        return result
    }

    val logsFlow: Flow<List<DailyLog>> = context.dataStore.data.map { prefs ->
        val raw = prefs[LOGS_KEY] ?: "[]"
        try { json.decodeFromString<List<DailyLog>>(raw) } catch (e: Exception) { emptyList() }
    }

    suspend fun saveDailyLog(log: DailyLog) {
        context.dataStore.edit { prefs ->
            val raw = prefs[LOGS_KEY] ?: "[]"
            val current: MutableList<DailyLog> = try {
                json.decodeFromString<List<DailyLog>>(raw).toMutableList()
            } catch (e: Exception) { mutableListOf() }
            val existingIdx = current.indexOfFirst { it.date == log.date }
            if (existingIdx >= 0) {
                current[existingIdx] = log
            } else {
                current.add(log)
            }
            prefs[LOGS_KEY] = json.encodeToString<List<DailyLog>>(current)
        }
    }

    val achievementsFlow: Flow<List<Achievement>> = context.dataStore.data.map { prefs ->
        val raw = prefs[ACHIEVEMENTS_KEY] ?: "[]"
        try { json.decodeFromString<List<Achievement>>(raw) } catch (e: Exception) { emptyList() }
    }

    suspend fun saveAchievements(achievements: List<Achievement>) {
        context.dataStore.edit { prefs ->
            prefs[ACHIEVEMENTS_KEY] = json.encodeToString(achievements)
        }
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        val theme = when (prefs[THEME_KEY]) {
            "light" -> ThemeMode.LIGHT
            "dark" -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
        val name = prefs[USER_NAME_KEY] ?: "Trader"
        val notif = prefs[NOTIFICATION_KEY] ?: "20:00"
        val parts = notif.split(":")
        UserSettings(
            themeMode = theme,
            userName = name,
            notificationHour = parts.getOrNull(0)?.toIntOrNull() ?: 20,
            notificationMinute = parts.getOrNull(1)?.toIntOrNull() ?: 0,
            tradeLockEnabled = prefs[TRADE_LOCK_ENABLED] ?: false,
            tradeLockThreshold = prefs[TRADE_LOCK_THRESHOLD] ?: 60,
            focusModeEnabled = prefs[FOCUS_MODE_ENABLED] ?: false,
            focusModeStartHour = prefs[FOCUS_START_HOUR] ?: 9,
            focusModeEndHour = prefs[FOCUS_END_HOUR] ?: 16
        )
    }

    suspend fun saveTheme(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[THEME_KEY] = when (mode) {
                ThemeMode.LIGHT -> "light"
                ThemeMode.DARK -> "dark"
                ThemeMode.SYSTEM -> "system"
            }
        }
    }

    suspend fun saveUserName(name: String) {
        context.dataStore.edit { prefs ->
            prefs[USER_NAME_KEY] = name
        }
    }

    suspend fun saveNotificationTime(hour: Int, minute: Int) {
        context.dataStore.edit { prefs ->
            prefs[NOTIFICATION_KEY] = "$hour:${minute.toString().padStart(2, '0')}"
        }
    }

    suspend fun saveTradeLock(enabled: Boolean, threshold: Int) {
        context.dataStore.edit { prefs ->
            prefs[TRADE_LOCK_ENABLED] = enabled
            prefs[TRADE_LOCK_THRESHOLD] = threshold
        }
    }

    suspend fun saveFocusMode(enabled: Boolean, startHour: Int, endHour: Int) {
        context.dataStore.edit { prefs ->
            prefs[FOCUS_MODE_ENABLED] = enabled
            prefs[FOCUS_START_HOUR] = startHour
            prefs[FOCUS_END_HOUR] = endHour
        }
    }
}
