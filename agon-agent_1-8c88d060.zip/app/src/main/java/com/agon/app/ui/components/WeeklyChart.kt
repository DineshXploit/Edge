package com.agon.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun WeeklyChart(
    data: List<Pair<String, Int>>,
    modifier: Modifier = Modifier
) {
    val maxHeight = 120.dp
    val emptyColor = MaterialTheme.colorScheme.surfaceVariant

    var animate by remember { mutableStateOf(false) }
    LaunchedEffect(data) {
        animate = false
        delay(100)
        animate = true
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        data.forEachIndexed { index, (label, score) ->
            val targetFraction = if (score >= 0 && animate) score / 100f else 0f
            val animatedFraction by animateFloatAsState(
                targetValue = targetFraction,
                animationSpec = tween(
                    durationMillis = 600,
                    delayMillis = index * 80,
                    easing = FastOutSlowInEasing
                ),
                label = "bar_$index"
            )
            val color = if (score >= 0) scoreColor(score) else emptyColor
            val glowColor = if (score >= 0) scoreGlowColor(score) else emptyColor

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(36.dp)
            ) {
                if (score >= 0) {
                    Text(
                        text = "$score",
                        style = MaterialTheme.typography.labelSmall,
                        color = color
                    )
                }
                Box(
                    modifier = Modifier
                        .height(maxHeight)
                        .width(24.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Canvas(
                        modifier = Modifier
                            .width(24.dp)
                            .height(maxHeight)
                    ) {
                        drawRoundRect(
                            color = emptyColor,
                            topLeft = Offset.Zero,
                            size = Size(size.width, size.height),
                            cornerRadius = CornerRadius(12f, 12f)
                        )
                        val barHeight = size.height * animatedFraction
                        if (barHeight > 0f) {
                            drawRoundRect(
                                brush = Brush.verticalGradient(
                                    colors = listOf(color, glowColor.copy(alpha = 0.7f)),
                                    startY = size.height - barHeight,
                                    endY = size.height
                                ),
                                topLeft = Offset(0f, size.height - barHeight),
                                size = Size(size.width, barHeight),
                                cornerRadius = CornerRadius(12f, 12f)
                            )
                        }
                    }
                }
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
