package com.agon.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.agon.app.ui.theme.EdgeGreen
import com.agon.app.ui.theme.EdgeGreenLight
import com.agon.app.ui.theme.EdgeAmber
import com.agon.app.ui.theme.EdgeRed
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private fun getHeatmapColor(score: Int): Color {
    return when {
        score >= 90 -> EdgeGreen
        score >= 80 -> EdgeGreenLight.copy(alpha = 0.8f)
        score >= 60 -> EdgeAmber.copy(alpha = 0.7f)
        score >= 40 -> EdgeRed.copy(alpha = 0.5f)
        score >= 0 -> EdgeRed.copy(alpha = 0.8f)
        else -> Color.Transparent
    }
}

data class HeatmapDay(
    val dateStr: String,
    val dayOfWeek: Int // 0=Sun, 6=Sat
)

@Composable
fun DisciplineHeatmap(
    heatmapData: Map<String, Int>,
    modifier: Modifier = Modifier
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val emptyColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)

    var animate by remember { mutableStateOf(false) }
    LaunchedEffect(heatmapData) {
        animate = false
        delay(100)
        animate = true
    }

    val animAlpha by animateFloatAsState(
        targetValue = if (animate) 1f else 0f,
        animationSpec = tween(800),
        label = "heatmap_alpha"
    )

    // Build day list for last 84 days (12 weeks)
    val allDays = remember {
        val list = mutableListOf<HeatmapDay>()
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -83)
        // Align to Sunday
        while (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        val endCal = Calendar.getInstance()
        while (!cal.after(endCal)) {
            val ds = dateFormat.format(cal.time)
            val dow = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0=Sun
            list.add(HeatmapDay(ds, dow))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        list
    }

    // Group into weeks (each week = list of up to 7 days)
    val weeks = remember(allDays) {
        val result = mutableListOf<List<HeatmapDay>>()
        var currentWeek = mutableListOf<HeatmapDay>()
        for (day in allDays) {
            if (day.dayOfWeek == 0 && currentWeek.isNotEmpty()) {
                result.add(currentWeek)
                currentWeek = mutableListOf()
            }
            currentWeek.add(day)
        }
        if (currentWeek.isNotEmpty()) result.add(currentWeek)
        result
    }

    val scrollState = rememberScrollState(Int.MAX_VALUE)

    Column(modifier = modifier) {
        Row {
            // Day labels column
            Column(
                modifier = Modifier.width(24.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf("", "M", "", "W", "", "F", "").forEach { label ->
                    Box(
                        modifier = Modifier.size(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Grid
            Row(
                modifier = Modifier.horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                weeks.forEach { week ->
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Fill missing days at start of week
                        val firstDow = week.firstOrNull()?.dayOfWeek ?: 0
                        repeat(firstDow) {
                            Canvas(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            ) {
                                // Empty placeholder
                            }
                        }
                        week.forEach { day ->
                            val score = heatmapData[day.dateStr]
                            val cellColor = if (score != null) {
                                getHeatmapColor(score).copy(alpha = animAlpha)
                            } else {
                                emptyColor
                            }
                            Canvas(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            ) {
                                drawRoundRect(
                                    color = cellColor,
                                    topLeft = Offset.Zero,
                                    size = Size(size.width, size.height),
                                    cornerRadius = CornerRadius(4f, 4f)
                                )
                            }
                        }
                        // Fill remaining days
                        val lastDow = week.lastOrNull()?.dayOfWeek ?: 6
                        repeat(6 - lastDow) {
                            Canvas(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            ) {
                                // Empty placeholder
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Legend
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Less",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            listOf(
                emptyColor,
                EdgeRed.copy(alpha = 0.5f),
                EdgeAmber.copy(alpha = 0.7f),
                EdgeGreenLight.copy(alpha = 0.8f),
                EdgeGreen
            ).forEach { color ->
                Canvas(modifier = Modifier.size(12.dp)) {
                    drawRoundRect(
                        color = color,
                        cornerRadius = CornerRadius(3f, 3f)
                    )
                }
            }
            Text(
                text = "More",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
