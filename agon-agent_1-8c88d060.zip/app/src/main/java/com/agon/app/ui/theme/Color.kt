package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

// Edge Brand Colors - Professional Trading App
// Primary: Deep Teal / Cyan
val EdgeTeal = Color(0xFF00BFA5)
val EdgeTealDark = Color(0xFF00897B)
val EdgeTealLight = Color(0xFF64FFDA)

// Accent: Amber for warnings/highlights
val EdgeAmber = Color(0xFFFFB300)
val EdgeAmberDark = Color(0xFFF57F17)

// Success / Positive
val EdgeGreen = Color(0xFF00C853)
val EdgeGreenLight = Color(0xFF69F0AE)
val EdgeGreenDark = Color(0xFF2E7D32)

// Danger / Negative
val EdgeRed = Color(0xFFFF1744)
val EdgeRedLight = Color(0xFFFF5252)
val EdgeRedDark = Color(0xFFC62828)

// Neutral
val EdgeGray50 = Color(0xFFFAFAFA)
val EdgeGray100 = Color(0xFFF5F5F5)
val EdgeGray200 = Color(0xFFEEEEEE)
val EdgeGray300 = Color(0xFFE0E0E0)
val EdgeGray400 = Color(0xFFBDBDBD)
val EdgeGray500 = Color(0xFF9E9E9E)
val EdgeGray600 = Color(0xFF757575)
val EdgeGray700 = Color(0xFF616161)
val EdgeGray800 = Color(0xFF424242)
val EdgeGray900 = Color(0xFF212121)

// Dark theme surfaces
val DarkSurface = Color(0xFF121212)
val DarkSurfaceVariant = Color(0xFF1E1E1E)
val DarkSurfaceElevated = Color(0xFF2C2C2C)
val DarkCard = Color(0xFF1A1A2E)

// Light theme surfaces
val LightSurface = Color(0xFFF8F9FA)
val LightSurfaceVariant = Color(0xFFFFFFFF)
val LightCard = Color(0xFFFFFFFF)

// Chart colors
val ChartBlue = Color(0xFF42A5F5)
val ChartPurple = Color(0xFFAB47BC)
val ChartOrange = Color(0xFFFF7043)
val ChartPink = Color(0xFFEC407A)
val ChartIndigo = Color(0xFF5C6BC0)
