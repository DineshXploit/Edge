package com.agon.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.ui.components.AnimatedFireIcon
import com.agon.app.ui.components.NewAchievementPopup
import com.agon.app.ui.components.ScoreCircle
import com.agon.app.ui.components.TradeLockWarning
import com.agon.app.ui.components.WeeklyChart
import com.agon.app.ui.components.scoreColor
import com.agon.app.ui.theme.EdgeGreen
import com.agon.app.viewmodel.EdgeViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: EdgeViewModel,
    onNavigateToDailyCheck: () -> Unit
) {
    val todayScore by viewModel.todayScore.collectAsState()
    val weeklyAvg by viewModel.weeklyAvg.collectAsState()
    val streak by viewModel.streak.collectAsState()
    val last7Days by viewModel.last7DaysScores.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val analytics by viewModel.analytics.collectAsState()
    val todayLogged by viewModel.todayLogged.collectAsState()
    val showTradeLock by viewModel.showTradeLockWarning.collectAsState()
    val newAchievement by viewModel.newAchievement.collectAsState()

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        viewModel.seedDefaultRulesIfEmpty()
        delay(100)
        visible = true
    }

    val todayFormatted = SimpleDateFormat("EEEE, MMM d", Locale.US).format(Date())

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Achievement popup
        if (newAchievement != null) {
            item {
                NewAchievementPopup(
                    achievement = newAchievement!!,
                    visible = true
                )
                LaunchedEffect(newAchievement) {
                    delay(4000)
                    viewModel.dismissNewAchievement()
                }
            }
        }

        // Header
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn() + slideInVertically { -50 }
            ) {
                Column {
                    Text(
                        text = "Welcome back,",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = settings.userName,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = todayFormatted,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Trade Lock Warning
        if (showTradeLock) {
            item {
                AnimatedVisibility(
                    visible = visible,
                    enter = scaleIn(spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow)) + fadeIn()
                ) {
                    TradeLockWarning(
                        score = todayScore,
                        threshold = settings.tradeLockThreshold
                    )
                }
            }
        }

        // Score Card
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn() + slideInVertically { 60 }
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (todayScore >= 0) {
                            Text(
                                text = "Today's Discipline Score",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            ScoreCircle(score = todayScore, size = 170.dp, strokeWidth = 14.dp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = when {
                                    todayScore >= 90 -> "\uD83D\uDD25 Exceptional discipline!"
                                    todayScore >= 80 -> "\u2705 Great job, stay focused!"
                                    todayScore >= 60 -> "\u26A0\uFE0F Room for improvement"
                                    else -> "\u274C Review your rules"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (todayLogged) {
                                Spacer(modifier = Modifier.height(8.dp))
                                TextButton(onClick = onNavigateToDailyCheck) {
                                    Text("Update Today's Log")
                                }
                            }
                        } else {
                            Text(
                                text = "Ready to log today?",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            ScoreCircle(score = -1, size = 130.dp, strokeWidth = 10.dp, showGlow = false)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onNavigateToDailyCheck,
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.EditNote,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Log Today's Discipline")
                            }
                        }
                    }
                }
            }
        }

        // Stats Row
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn() + slideInVertically { 80 }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Weekly Average
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (weeklyAvg >= 0) "$weeklyAvg" else "--",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (weeklyAvg >= 0) scoreColor(weeklyAvg) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Weekly Avg",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Streak
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            AnimatedFireIcon(streak = streak, size = 28.dp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "$streak",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (streak > 0) EdgeGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Day Streak",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Status
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (todayLogged) EdgeGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (todayLogged) "Done" else "Pending",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (todayLogged) EdgeGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Today",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Weekly Chart
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn() + slideInVertically { 100 }
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "Last 7 Days",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        if (last7Days.isNotEmpty()) {
                            WeeklyChart(data = last7Days)
                        } else {
                            Text(
                                text = "No data yet. Start logging!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Quick Insights
        item {
            if (analytics.insights.isNotEmpty()) {
                AnimatedVisibility(
                    visible = visible,
                    enter = fadeIn() + slideInVertically { 120 }
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                text = "\uD83D\uDCA1 Insights",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            analytics.insights.take(3).forEach { insight ->
                                Text(
                                    text = "\u2022 $insight",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(8.dp)) }
    }
}
