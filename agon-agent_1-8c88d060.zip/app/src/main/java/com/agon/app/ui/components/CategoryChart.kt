package com.agon.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.agon.app.data.RuleCategory
import com.agon.app.ui.theme.ChartBlue
import com.agon.app.ui.theme.ChartOrange
import com.agon.app.ui.theme.ChartPink
import com.agon.app.ui.theme.ChartPurple
import com.agon.app.ui.theme.ChartIndigo

fun categoryColor(category: RuleCategory): Color {
    return when (category) {
        RuleCategory.PSYCHOLOGY -> ChartPurple
        RuleCategory.RISK -> ChartOrange
        RuleCategory.ENTRY -> ChartBlue
        RuleCategory.EXIT -> ChartPink
        RuleCategory.GENERAL -> ChartIndigo
    }
}

@Composable
fun CategoryBreakdown(
    categoryScores: Map<RuleCategory, Float>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        categoryScores.entries.forEachIndexed { index, (category, score) ->
            val animatedProgress by animateFloatAsState(
                targetValue = (score / 100f).coerceIn(0f, 1f),
                animationSpec = tween(
                    durationMillis = 800,
                    delayMillis = index * 100,
                    easing = FastOutSlowInEasing
                ),
                label = "cat_${category.name}"
            )
            val color = categoryColor(category)
            val catName = category.name.lowercase().replaceFirstChar { it.uppercase() }

            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Canvas(modifier = Modifier.size(10.dp)) {
                            drawCircle(color = color)
                        }
                        Text(
                            text = catName,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Text(
                        text = "${score.toInt()}%",
                        style = MaterialTheme.typography.labelLarge,
                        color = color
                    )
                }
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = color,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    strokeCap = StrokeCap.Round
                )
            }
        }
    }
}
