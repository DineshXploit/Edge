package com.agon.app.data

import kotlinx.serialization.Serializable

@Serializable
enum class RuleType {
    BOOLEAN, SCALE_5, SCALE_10
}

@Serializable
enum class RuleCategory {
    PSYCHOLOGY, RISK, ENTRY, EXIT, GENERAL
}

@Serializable
data class Rule(
    val id: String = "",
    val name: String = "",
    val type: RuleType = RuleType.BOOLEAN,
    val penalty: Int = 10,
    val category: RuleCategory = RuleCategory.GENERAL,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class DailyLog(
    val id: String = "",
    val date: String = "",
    val responses: Map<String, Float> = emptyMap(),
    val score: Int = 100,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class AppData(
    val rules: List<Rule> = emptyList(),
    val logs: List<DailyLog> = emptyList()
)

enum class ThemeMode {
    LIGHT, DARK, SYSTEM
}

data class UserSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val userName: String = "Trader",
    val notificationHour: Int = 20,
    val notificationMinute: Int = 0,
    val tradeLockEnabled: Boolean = false,
    val tradeLockThreshold: Int = 60,
    val focusModeEnabled: Boolean = false,
    val focusModeStartHour: Int = 9,
    val focusModeEndHour: Int = 16
)

data class AnalyticsData(
    val mostViolatedRule: Rule? = null,
    val mostViolatedCount: Int = 0,
    val weakestCategory: RuleCategory? = null,
    val weakestCategoryScore: Float = 0f,
    val bestDay: String = "",
    val bestDayScore: Int = 0,
    val insights: List<String> = emptyList(),
    val categoryScores: Map<RuleCategory, Float> = emptyMap(),
    val ruleViolationCounts: Map<String, Int> = emptyMap()
)

@Serializable
data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    val icon: String,
    val requirement: Int,
    val unlockedAt: Long = 0L
) {
    val isUnlocked: Boolean get() = unlockedAt > 0L
}

val ALL_ACHIEVEMENTS = listOf(
    Achievement("streak_3", "Getting Started", "Maintain a 3-day discipline streak", "fire", 3),
    Achievement("streak_7", "One Week Strong", "Maintain a 7-day discipline streak", "fire", 7),
    Achievement("streak_14", "Two Week Warrior", "Maintain a 14-day discipline streak", "fire", 14),
    Achievement("streak_30", "Monthly Master", "Maintain a 30-day discipline streak", "fire", 30),
    Achievement("streak_60", "Diamond Hands", "Maintain a 60-day discipline streak", "diamond", 60),
    Achievement("streak_100", "Legendary Trader", "Maintain a 100-day discipline streak", "trophy", 100),
    Achievement("logs_5", "First Steps", "Complete 5 daily check-ins", "check", 5),
    Achievement("logs_25", "Dedicated", "Complete 25 daily check-ins", "check", 25),
    Achievement("logs_50", "Committed", "Complete 50 daily check-ins", "check", 50),
    Achievement("logs_100", "Centurion", "Complete 100 daily check-ins", "check", 100),
    Achievement("perfect_1", "Perfect Day", "Score 100 on a single day", "star", 1),
    Achievement("perfect_5", "Perfectionist", "Score 100 on 5 different days", "star", 5),
    Achievement("rules_5", "Rule Maker", "Create 5 custom rules", "rule", 5),
    Achievement("rules_10", "System Builder", "Create 10 custom rules", "rule", 10)
)

enum class AnalyticsPeriod {
    DAILY, WEEKLY, MONTHLY
}
