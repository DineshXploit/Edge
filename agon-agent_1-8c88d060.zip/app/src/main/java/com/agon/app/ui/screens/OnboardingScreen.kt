package com.agon.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.ui.theme.EdgeTeal
import com.agon.app.ui.theme.EdgeTealLight
import kotlinx.coroutines.delay

// ─────────────────────────────────────────────────────────────
// Onboarding Host — manages step transitions
// ─────────────────────────────────────────────────────────────

@Composable
fun OnboardingScreen(
    onComplete: (String) -> Unit
) {
    var currentStep by remember { mutableStateOf(0) }
    var userName by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0A0A0F),
                        Color(0xFF0D1117),
                        Color(0xFF0A0E14)
                    )
                )
            )
    ) {
        // Ambient glow particles
        AmbientGlow()

        AnimatedVisibility(
            visible = currentStep == 0,
            enter = fadeIn(tween(500)),
            exit = fadeOut(tween(300)) + slideOutVertically(
                targetOffsetY = { -it / 4 },
                animationSpec = tween(300)
            )
        ) {
            SplashStep(
                onGetStarted = { currentStep = 1 }
            )
        }

        AnimatedVisibility(
            visible = currentStep == 1,
            enter = fadeIn(tween(400, delayMillis = 200)) + slideInVertically(
                initialOffsetY = { it / 4 },
                animationSpec = tween(500, delayMillis = 200, easing = FastOutSlowInEasing)
            ),
            exit = fadeOut(tween(200))
        ) {
            NameInputStep(
                name = userName,
                onNameChange = { userName = it },
                onContinue = { onComplete(userName.trim()) }
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Ambient background glow
// ─────────────────────────────────────────────────────────────

@Composable
fun AmbientGlow() {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient")
    val glowOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_offset"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.05f,
        targetValue = 0.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * (0.3f + 0.4f * glowOffset)
        val cy = size.height * 0.35f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    EdgeTeal.copy(alpha = glowAlpha),
                    Color.Transparent
                ),
                center = Offset(cx, cy),
                radius = size.width * 0.6f
            ),
            center = Offset(cx, cy),
            radius = size.width * 0.6f
        )
        // Second glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    EdgeTealLight.copy(alpha = glowAlpha * 0.5f),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.7f, size.height * 0.7f),
                radius = size.width * 0.4f
            ),
            center = Offset(size.width * 0.7f, size.height * 0.7f),
            radius = size.width * 0.4f
        )
    }
}

// ─────────────────────────────────────────────────────────────
// STEP 1: Splash / Intro
// ─────────────────────────────────────────────────────────────

@Composable
fun SplashStep(onGetStarted: () -> Unit) {
    // Staggered fade-in
    var showLogo by remember { mutableStateOf(false) }
    var showTagline by remember { mutableStateOf(false) }
    var showButton by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(400)
        showLogo = true
        delay(500)
        showTagline = true
        delay(400)
        showButton = true
    }

    // Logo ring animation
    val ringProgress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(300)
        ringProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(1200, easing = FastOutSlowInEasing)
        )
    }

    val buttonScale by animateFloatAsState(
        targetValue = if (showButton) 1f else 0.8f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow),
        label = "btn_scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.weight(1f))

        // Logo with animated ring
        AnimatedVisibility(
            visible = showLogo,
            enter = fadeIn(tween(800)) + slideInVertically(
                initialOffsetY = { 30 },
                animationSpec = tween(800, easing = FastOutSlowInEasing)
            )
        ) {
            Box(contentAlignment = Alignment.Center) {
                // Animated ring
                Canvas(modifier = Modifier.size(130.dp)) {
                    val strokeW = 3.dp.toPx()
                    drawArc(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                EdgeTeal.copy(alpha = 0.8f),
                                EdgeTealLight.copy(alpha = 0.4f),
                                Color.Transparent,
                                EdgeTeal.copy(alpha = 0.6f)
                            )
                        ),
                        startAngle = -90f,
                        sweepAngle = 360f * ringProgress.value,
                        useCenter = false,
                        style = Stroke(width = strokeW, cap = StrokeCap.Round)
                    )
                }
                // Inner icon
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    EdgeTeal.copy(alpha = 0.15f),
                                    Color.Transparent
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.ShowChart,
                        contentDescription = null,
                        tint = EdgeTeal,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(36.dp))

        // App name
        AnimatedVisibility(
            visible = showLogo,
            enter = fadeIn(tween(600, delayMillis = 200))
        ) {
            Text(
                text = "EDGE",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 10.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tagline
        AnimatedVisibility(
            visible = showTagline,
            enter = fadeIn(tween(600)) + slideInVertically(
                initialOffsetY = { 20 },
                animationSpec = tween(600, easing = FastOutSlowInEasing)
            )
        ) {
            Text(
                text = "Master Your Own Discipline",
                style = MaterialTheme.typography.titleMedium,
                color = EdgeTeal.copy(alpha = 0.9f),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        AnimatedVisibility(
            visible = showTagline,
            enter = fadeIn(tween(600, delayMillis = 200))
        ) {
            Text(
                text = "Build your trading system.\nTrack your rules. Stay disciplined.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF8B95A5),
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        // Get Started button
        AnimatedVisibility(
            visible = showButton,
            enter = fadeIn(tween(500))
        ) {
            Button(
                onClick = onGetStarted,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .scale(buttonScale),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EdgeTeal,
                    contentColor = Color.Black
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 0.dp,
                    pressedElevation = 0.dp
                )
            ) {
                Text(
                    text = "Get Started",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(48.dp))

        // Step indicator
        AnimatedVisibility(
            visible = showButton,
            enter = fadeIn(tween(400, delayMillis = 200))
        ) {
            StepIndicator(currentStep = 0, totalSteps = 2)
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

// ─────────────────────────────────────────────────────────────
// STEP 2: Name Input
// ─────────────────────────────────────────────────────────────

@Composable
fun NameInputStep(
    name: String,
    onNameChange: (String) -> Unit,
    onContinue: () -> Unit
) {
    val focusManager = LocalFocusManager.current
    var showContent by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(100)
        showContent = true
    }

    val buttonScale by animateFloatAsState(
        targetValue = if (name.isNotBlank()) 1f else 0.95f,
        animationSpec = spring(dampingRatio = 0.6f),
        label = "continue_scale"
    )

    fun trySubmit() {
        if (name.isBlank()) {
            nameError = true
        } else {
            focusManager.clearFocus()
            onContinue()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp)
            .imePadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.weight(1f))

        // Avatar circle
        AnimatedVisibility(
            visible = showContent,
            enter = fadeIn(tween(500)) + slideInVertically(
                initialOffsetY = { 30 },
                animationSpec = tween(500, easing = FastOutSlowInEasing)
            )
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(EdgeTeal.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Person,
                    contentDescription = null,
                    tint = EdgeTeal,
                    modifier = Modifier.size(40.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        AnimatedVisibility(
            visible = showContent,
            enter = fadeIn(tween(500, delayMillis = 100))
        ) {
            Text(
                text = "What should we call you?",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        AnimatedVisibility(
            visible = showContent,
            enter = fadeIn(tween(500, delayMillis = 200))
        ) {
            Text(
                text = "Enter your display name to personalize\nyour discipline tracking experience.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF8B95A5),
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }

        Spacer(modifier = Modifier.height(36.dp))

        // Name input
        AnimatedVisibility(
            visible = showContent,
            enter = fadeIn(tween(500, delayMillis = 300)) + slideInVertically(
                initialOffsetY = { 20 },
                animationSpec = tween(500, delayMillis = 300, easing = FastOutSlowInEasing)
            )
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { onNameChange(it); nameError = false },
                placeholder = {
                    Text("Your Name", color = Color(0xFF4A5568))
                },
                singleLine = true,
                isError = nameError,
                supportingText = if (nameError) {
                    { Text("Please enter your name", color = Color(0xFFFF5252)) }
                } else null,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Words,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { trySubmit() }
                ),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EdgeTeal,
                    unfocusedBorderColor = Color(0xFF2A3040),
                    cursorColor = EdgeTeal,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    errorBorderColor = Color(0xFFFF5252),
                    focusedContainerColor = Color(0xFF141820),
                    unfocusedContainerColor = Color(0xFF141820),
                    errorContainerColor = Color(0xFF1A1418)
                )
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        // Continue button
        AnimatedVisibility(
            visible = showContent,
            enter = fadeIn(tween(500, delayMillis = 400))
        ) {
            Button(
                onClick = { trySubmit() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .scale(buttonScale),
                shape = RoundedCornerShape(18.dp),
                enabled = true,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (name.isNotBlank()) EdgeTeal else EdgeTeal.copy(alpha = 0.3f),
                    contentColor = if (name.isNotBlank()) Color.Black else Color.White.copy(alpha = 0.5f)
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 0.dp,
                    pressedElevation = 0.dp
                )
            ) {
                Text(
                    text = "Continue",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(48.dp))

        // Step indicator
        AnimatedVisibility(
            visible = showContent,
            enter = fadeIn(tween(400, delayMillis = 400))
        ) {
            StepIndicator(currentStep = 1, totalSteps = 2)
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

// ─────────────────────────────────────────────────────────────
// Step Indicator Dots
// ─────────────────────────────────────────────────────────────

@Composable
fun StepIndicator(currentStep: Int, totalSteps: Int) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(totalSteps) { index ->
            val isActive = index == currentStep
            val dotWidth by animateFloatAsState(
                targetValue = if (isActive) 28f else 8f,
                animationSpec = spring(dampingRatio = 0.7f),
                label = "dot_$index"
            )
            val dotAlpha by animateFloatAsState(
                targetValue = if (isActive) 1f else 0.3f,
                animationSpec = tween(300),
                label = "dot_alpha_$index"
            )
            Box(
                modifier = Modifier
                    .height(8.dp)
                    .width(dotWidth.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .alpha(dotAlpha)
                    .background(EdgeTeal)
            )
        }
    }
}
