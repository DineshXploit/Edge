package com.agon.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.agon.app.data.RuleCategory
import kotlinx.coroutines.delay

@Composable
fun RulePerformanceBarChart(
    data: List<Triple<String, Float, RuleCategory>>,
    modifier: Modifier = Modifier
) {
    if (data.isEmpty()) return

    var animate by remember { mutableStateOf(false) }
    LaunchedEffect(data) {
        animate = false
        delay(100)
        animate = true
    }

    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(scrollState),
        verticalAlignment = Alignment.Bottom
    ) {
        data.forEachIndexed { index, (name, compliance, category) ->
            val targetFraction = if (animate) (compliance / 100f).coerceIn(0f, 1f) else 0f
            val animatedFraction by animateFloatAsState(
                targetValue = targetFraction,
                animationSpec = tween(
                    durationMillis = 700,
                    delayMillis = index * 100,
                    easing = FastOutSlowInEasing
                ),
                label = "rule_bar_$index"
            )
            val color = categoryColor(category)
            val emptyColor = MaterialTheme.colorScheme.surfaceVariant

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(56.dp)
                    .padding(horizontal = 4.dp)
            ) {
                Text(
                    text = "${compliance.toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = color
                )
                Spacer(modifier = Modifier.height(2.dp))
                Canvas(
                    modifier = Modifier
                        .width(32.dp)
                        .height(100.dp)
                ) {
                    drawRoundRect(
                        color = emptyColor,
                        topLeft = Offset.Zero,
                        size = Size(size.width, size.height),
                        cornerRadius = CornerRadius(10f, 10f)
                    )
                    val barH = size.height * animatedFraction
                    if (barH > 0f) {
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(color, color.copy(alpha = 0.6f)),
                                startY = size.height - barH,
                                endY = size.height
                            ),
                            topLeft = Offset(0f, size.height - barH),
                            size = Size(size.width, barH),
                            cornerRadius = CornerRadius(10f, 10f)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = name.take(8),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
