package com.agon.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.data.ThemeMode
import com.agon.app.ui.theme.ChartBlue
import com.agon.app.ui.theme.ChartIndigo
import com.agon.app.ui.theme.ChartOrange
import com.agon.app.ui.theme.ChartPurple
import com.agon.app.ui.theme.EdgeAmber
import com.agon.app.ui.theme.EdgeGreen
import com.agon.app.ui.theme.EdgeRed
import com.agon.app.ui.theme.EdgeTeal
import androidx.compose.ui.unit.sp
import com.agon.app.viewmodel.EdgeViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

// ─────────────────────────────────────────────────────────────
// Settings Screen
// ─────────────────────────────────────────────────────────────

@Composable
fun SettingsScreen(
    viewModel: EdgeViewModel,
    snackbarHostState: SnackbarHostState = remember { SnackbarHostState() }
) {
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showNameDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showNotifDialog by remember { mutableStateOf(false) }
    var showTradeLockDialog by remember { mutableStateOf(false) }
    var showFocusModeDialog by remember { mutableStateOf(false) }

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(80)
        visible = true
    }

    fun openExternalLink(url: String, snackbarMessage: String) {
        scope.launch {
            snackbarHostState.showSnackbar(
                message = snackbarMessage,
                duration = SnackbarDuration.Short
            )
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            scope.launch {
                snackbarHostState.showSnackbar(
                    message = "Unable to open link. Please try again.",
                    duration = SnackbarDuration.Short
                )
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // ── Header ──────────────────────────────────────────
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(300)) + slideInVertically { -40 }
            ) {
                Column {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Manage your preferences",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // ── 1. GENERAL ─────────────────────────────────────
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(350)) + slideInVertically { 50 }
            ) {
                SettingsGroup(label = "GENERAL") {
                    val themeIcon = when (settings.themeMode) {
                        ThemeMode.LIGHT -> Icons.Default.LightMode
                        ThemeMode.DARK -> Icons.Default.DarkMode
                        ThemeMode.SYSTEM -> Icons.Default.PhoneAndroid
                    }
                    val themeLabel = when (settings.themeMode) {
                        ThemeMode.LIGHT -> "Light"
                        ThemeMode.DARK -> "Dark"
                        ThemeMode.SYSTEM -> "System Default"
                    }
                    SettingsTile(
                        icon = Icons.Default.Palette,
                        iconTint = ChartPurple,
                        title = "Theme",
                        subtitle = themeLabel,
                        showChevron = true,
                        onClick = { showThemeDialog = true }
                    )
                    TileDivider()
                    SettingsTile(
                        icon = Icons.Default.Notifications,
                        iconTint = ChartBlue,
                        title = "Daily Reminder",
                        subtitle = "${settings.notificationHour.toString().padStart(2, '0')}:${settings.notificationMinute.toString().padStart(2, '0')}",
                        showChevron = true,
                        onClick = { showNotifDialog = true }
                    )
                    TileDivider()
                    SettingsTile(
                        icon = Icons.Default.Person,
                        iconTint = EdgeTeal,
                        title = "Display Name",
                        subtitle = settings.userName,
                        showChevron = true,
                        onClick = { showNameDialog = true }
                    )
                }
            }
        }

        // ── 2. TRADING ─────────────────────────────────────
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(400)) + slideInVertically { 60 }
            ) {
                SettingsGroup(label = "TRADING") {
                    SettingsTile(
                        icon = Icons.Default.Lock,
                        iconTint = EdgeRed,
                        title = "Trade Lock Mode",
                        subtitle = if (settings.tradeLockEnabled)
                            "Active \u2022 Threshold ${settings.tradeLockThreshold}"
                        else "Disabled",
                        showChevron = true,
                        onClick = { showTradeLockDialog = true }
                    )
                    TileDivider()
                    SettingsTile(
                        icon = Icons.Default.Visibility,
                        iconTint = ChartIndigo,
                        title = "Focus Mode",
                        subtitle = if (settings.focusModeEnabled)
                            "Active \u2022 ${settings.focusModeStartHour}:00\u2013${settings.focusModeEndHour}:00"
                        else "Disabled",
                        showChevron = true,
                        onClick = { showFocusModeDialog = true }
                    )
                    TileDivider()
                    SettingsTile(
                        icon = Icons.Default.Share,
                        iconTint = EdgeGreen,
                        title = "Export Report",
                        subtitle = "Generate & share discipline report",
                        showChevron = true,
                        onClick = { viewModel.shareReport(context) }
                    )
                }
            }
        }

        // ── 3. SUPPORT & LEGAL ─────────────────────────────
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(450)) + slideInVertically { 70 }
            ) {
                SettingsGroup(label = "SUPPORT & LEGAL") {
                    SettingsTile(
                        icon = Icons.Default.PrivacyTip,
                        iconTint = EdgeAmber,
                        title = "Privacy Policy",
                        subtitle = "View how your data is handled",
                        showChevron = true,
                        onClick = {
                            openExternalLink(
                                url = "https://ugzn96.vercel.app/privacy.html",
                                snackbarMessage = "Opening Privacy Policy\u2026"
                            )
                        }
                    )
                    TileDivider()
                    SettingsTile(
                        icon = Icons.Default.SupportAgent,
                        iconTint = ChartBlue,
                        title = "Contact Us",
                        subtitle = "Get help or send feedback",
                        showChevron = true,
                        onClick = {
                            openExternalLink(
                                url = "https://ugzn96.vercel.app/contact.html",
                                snackbarMessage = "Opening Contact Page\u2026"
                            )
                        }
                    )
                }
            }
        }

        // ── 4. ABOUT ───────────────────────────────────────
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(500)) + slideInVertically { 80 }
            ) {
                SettingsGroup(label = "ABOUT") {
                    SettingsTile(
                        icon = Icons.Outlined.Info,
                        iconTint = MaterialTheme.colorScheme.primary,
                        title = "Edge",
                        subtitle = "Master the Discipline",
                        showChevron = false,
                        onClick = {}
                    )
                    TileDivider()
                    SettingsTile(
                        icon = Icons.Default.Code,
                        iconTint = ChartOrange,
                        title = "Version",
                        subtitle = "v1.0.0",
                        showChevron = false,
                        onClick = {}
                    )
                }
            }
        }

        // Bottom spacing
        item { Spacer(modifier = Modifier.height(12.dp)) }
    }

    // ── Dialogs ─────────────────────────────────────────────

    if (showNameDialog) {
        var nameValue by remember { mutableStateOf(settings.userName) }
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            title = { Text("Display Name") },
            text = {
                OutlinedTextField(
                    value = nameValue,
                    onValueChange = { nameValue = it },
                    label = { Text("Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (nameValue.isNotBlank()) viewModel.setUserName(nameValue.trim())
                    showNameDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showNameDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("Choose Theme") },
            text = {
                Column {
                    ThemeMode.entries.forEach { mode ->
                        val icon = when (mode) {
                            ThemeMode.LIGHT -> Icons.Default.LightMode
                            ThemeMode.DARK -> Icons.Default.DarkMode
                            ThemeMode.SYSTEM -> Icons.Default.PhoneAndroid
                        }
                        val label = when (mode) {
                            ThemeMode.LIGHT -> "Light Mode"
                            ThemeMode.DARK -> "Dark Mode"
                            ThemeMode.SYSTEM -> "System Default"
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    viewModel.setTheme(mode)
                                    showThemeDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = settings.themeMode == mode,
                                onClick = {
                                    viewModel.setTheme(mode)
                                    showThemeDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = label, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) { Text("Done") }
            }
        )
    }

    if (showNotifDialog) {
        var selectedHour by remember { mutableIntStateOf(settings.notificationHour) }
        AlertDialog(
            onDismissRequest = { showNotifDialog = false },
            title = { Text("Reminder Time") },
            text = {
                Column {
                    Text(
                        text = "Select hour for daily reminder",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    listOf(7, 8, 9, 12, 17, 18, 19, 20, 21, 22).forEach { hour ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { selectedHour = hour }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedHour == hour,
                                onClick = { selectedHour = hour }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                Icons.Default.Timer,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${hour.toString().padStart(2, '0')}:00",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.setNotificationTime(selectedHour, 0)
                    showNotifDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showNotifDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showTradeLockDialog) {
        var enabled by remember { mutableStateOf(settings.tradeLockEnabled) }
        var threshold by remember { mutableFloatStateOf(settings.tradeLockThreshold.toFloat()) }
        AlertDialog(
            onDismissRequest = { showTradeLockDialog = false },
            title = { Text("Trade Lock Mode") },
            text = {
                Column {
                    Text(
                        text = "Shows a warning when your discipline score drops below the threshold. Protects you from impulsive trading.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Enable Trade Lock", style = MaterialTheme.typography.bodyLarge)
                        Switch(
                            checked = enabled,
                            onCheckedChange = { enabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.primary,
                                checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                    if (enabled) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Threshold: ${threshold.roundToInt()}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Slider(
                            value = threshold,
                            onValueChange = { threshold = it },
                            valueRange = 30f..80f,
                            steps = 9
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.setTradeLock(enabled, threshold.roundToInt())
                    showTradeLockDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showTradeLockDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showFocusModeDialog) {
        var enabled by remember { mutableStateOf(settings.focusModeEnabled) }
        var startHour by remember { mutableFloatStateOf(settings.focusModeStartHour.toFloat()) }
        var endHour by remember { mutableFloatStateOf(settings.focusModeEndHour.toFloat()) }
        AlertDialog(
            onDismissRequest = { showFocusModeDialog = false },
            title = { Text("Focus Mode") },
            text = {
                Column {
                    Text(
                        text = "Minimal UI during trading hours to reduce distractions and keep you in the zone.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Enable Focus Mode", style = MaterialTheme.typography.bodyLarge)
                        Switch(
                            checked = enabled,
                            onCheckedChange = { enabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.primary,
                                checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                    if (enabled) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Start: ${startHour.roundToInt()}:00",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Slider(
                            value = startHour,
                            onValueChange = { startHour = it },
                            valueRange = 6f..14f,
                            steps = 7
                        )
                        Text(
                            text = "End: ${endHour.roundToInt()}:00",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Slider(
                            value = endHour,
                            onValueChange = { endHour = it },
                            valueRange = 14f..22f,
                            steps = 7
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.setFocusMode(enabled, startHour.roundToInt(), endHour.roundToInt())
                    showFocusModeDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showFocusModeDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────
// Grouped Card Section
// ─────────────────────────────────────────────────────────────

@Composable
fun SettingsGroup(
    label: String,
    content: @Composable () -> Unit
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 6.dp, bottom = 8.dp),
            letterSpacing = 1.sp
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                content()
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Single Tile inside a Group
// ─────────────────────────────────────────────────────────────

@Composable
fun SettingsTile(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    showChevron: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(),
                onClick = onClick
            )
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Tinted icon circle
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(iconTint.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (showChevron) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Divider between tiles
// ─────────────────────────────────────────────────────────────

@Composable
fun TileDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 68.dp, end = 16.dp),
        thickness = 0.5.dp,
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
    )
}


