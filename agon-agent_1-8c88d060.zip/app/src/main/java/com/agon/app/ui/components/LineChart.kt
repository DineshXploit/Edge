package com.agon.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.agon.app.ui.theme.EdgeTeal
import com.agon.app.ui.theme.EdgeTealLight
import kotlinx.coroutines.delay

@Composable
fun LineChart(
    data: List<Pair<String, Int>>,
    modifier: Modifier = Modifier,
    lineColor: Color = EdgeTeal,
    fillColor: Color = EdgeTealLight
) {
    val validData = data.filter { it.second >= 0 }
    if (validData.size < 2) return

    var animate by remember { mutableStateOf(false) }
    LaunchedEffect(data) {
        animate = false
        delay(50)
        animate = true
    }

    val progress by animateFloatAsState(
        targetValue = if (animate) 1f else 0f,
        animationSpec = tween(1200, easing = FastOutSlowInEasing),
        label = "line_progress"
    )

    val gridColor = MaterialTheme.colorScheme.outlineVariant

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(160.dp)
    ) {
        val w = size.width
        val h = size.height
        val padding = 8f
        val chartW = w - padding * 2
        val chartH = h - padding * 2

        // Grid lines
        for (i in 0..4) {
            val y = padding + chartH * (1f - i / 4f)
            drawLine(
                color = gridColor,
                start = Offset(padding, y),
                end = Offset(w - padding, y),
                strokeWidth = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
            )
        }

        val points = validData.mapIndexed { index, (_, score) ->
            val x = padding + (index.toFloat() / (validData.size - 1)) * chartW
            val y = padding + chartH * (1f - score / 100f)
            Offset(x, y)
        }

        val visibleCount = (points.size * progress).toInt().coerceAtLeast(2)
        val visiblePoints = points.take(visibleCount)

        // Fill area
        if (visiblePoints.size >= 2) {
            val fillPath = Path().apply {
                moveTo(visiblePoints.first().x, h - padding)
                visiblePoints.forEach { lineTo(it.x, it.y) }
                lineTo(visiblePoints.last().x, h - padding)
                close()
            }
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        fillColor.copy(alpha = 0.3f),
                        fillColor.copy(alpha = 0.02f)
                    )
                )
            )

            // Line
            val linePath = Path().apply {
                moveTo(visiblePoints.first().x, visiblePoints.first().y)
                for (i in 1 until visiblePoints.size) {
                    val prev = visiblePoints[i - 1]
                    val curr = visiblePoints[i]
                    val cpx1 = prev.x + (curr.x - prev.x) / 3f
                    val cpx2 = prev.x + (curr.x - prev.x) * 2f / 3f
                    cubicTo(cpx1, prev.y, cpx2, curr.y, curr.x, curr.y)
                }
            }
            drawPath(
                path = linePath,
                color = lineColor,
                style = Stroke(
                    width = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )

            // Dots
            visiblePoints.forEachIndexed { i, point ->
                val dotColor = scoreColor(validData[i].second)
                drawCircle(
                    color = dotColor.copy(alpha = 0.3f),
                    radius = 8f,
                    center = point
                )
                drawCircle(
                    color = dotColor,
                    radius = 5f,
                    center = point
                )
                drawCircle(
                    color = Color.White,
                    radius = 2.5f,
                    center = point
                )
            }
        }
    }
}
