package com.agon.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.agon.app.ui.theme.EdgeGreen
import com.agon.app.ui.theme.EdgeGreenLight
import com.agon.app.ui.theme.EdgeAmber
import com.agon.app.ui.theme.EdgeRed
import com.agon.app.ui.theme.EdgeRedLight
import com.agon.app.ui.theme.EdgeTeal
import com.agon.app.ui.theme.EdgeTealLight

fun scoreColor(score: Int): Color {
    return when {
        score >= 80 -> EdgeGreen
        score >= 50 -> EdgeAmber
        else -> EdgeRed
    }
}

fun scoreGlowColor(score: Int): Color {
    return when {
        score >= 80 -> EdgeGreenLight
        score >= 50 -> EdgeAmber.copy(alpha = 0.5f)
        else -> EdgeRedLight
    }
}

@Composable
fun ScoreCircle(
    score: Int,
    size: Dp = 160.dp,
    strokeWidth: Dp = 12.dp,
    label: String = "Score",
    showGlow: Boolean = true
) {
    val animatedProgress by animateFloatAsState(
        targetValue = score / 100f,
        animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
        label = "score_progress"
    )
    val color = scoreColor(score)
    val glowColor = scoreGlowColor(score)
    val trackColor = MaterialTheme.colorScheme.surfaceVariant

    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.45f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Box(contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(size)) {
            val strokePx = strokeWidth.toPx()
            val stroke = Stroke(width = strokePx, cap = StrokeCap.Round)

            // Outer glow
            if (showGlow && score >= 0) {
                val glowStroke = Stroke(width = strokePx * 2.5f, cap = StrokeCap.Round)
                drawArc(
                    color = glowColor.copy(alpha = glowAlpha * animatedProgress),
                    startAngle = -90f,
                    sweepAngle = 360f * animatedProgress,
                    useCenter = false,
                    style = glowStroke
                )
            }

            // Background track
            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = stroke
            )

            // Gradient progress arc
            rotate(degrees = -90f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            color.copy(alpha = 0.6f),
                            color,
                            color.copy(alpha = 0.9f)
                        )
                    ),
                    startAngle = 0f,
                    sweepAngle = 360f * animatedProgress,
                    useCenter = false,
                    style = stroke
                )
            }

            // Tip dot
            if (animatedProgress > 0.02f) {
                val angle = Math.toRadians((-90.0 + 360.0 * animatedProgress))
                val radius = (this.size.minDimension - strokePx) / 2f
                val cx = this.size.width / 2f + radius * Math.cos(angle).toFloat()
                val cy = this.size.height / 2f + radius * Math.sin(angle).toFloat()
                drawCircle(
                    color = Color.White,
                    radius = strokePx * 0.35f,
                    center = Offset(cx, cy)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (score >= 0) "$score" else "--",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = if (score >= 0) color else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
